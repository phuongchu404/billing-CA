import request from '../request/request';
import { doGet } from '../../utils';

export async function getSerialNumber(data: any) {
    const result = await Utils.doG
    return request({ url: '/api/cks', method: "get" , params: data });
}