import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router';
import HomeView from '../views/HomeView.vue';
import HomePage from '@/components/home/index.vue';
import SearchCerti from '@/components/searchCerti/index.vue';
import AboutPage from '@/components/about/index.vue';
import GuidePage from '@/components/guide/index.vue';

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    name: 'home',
    component: HomeView,
    children: [
      { path: '', name: 'home-page', component: HomePage },
      { path: 'search', name: 'search-page', component: SearchCerti },
      { path: 'about', name: 'about', component: AboutPage },
      { path: 'guide', name: 'guide', component: GuidePage },
    ],
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
  scrollBehavior(to, from, savedPosition) {
    if (to.hash) {
      return { el: to.hash, behavior: 'smooth' };
    } else if (savedPosition) {
      return savedPosition;
    } else {
      return { top: 0 };
    }
  },
});

export default router;
