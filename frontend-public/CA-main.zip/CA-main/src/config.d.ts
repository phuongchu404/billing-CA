interface Window {
    configurl: string;
}