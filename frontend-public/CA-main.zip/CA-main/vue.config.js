const { defineConfig } = require('@vue/cli-service');
const path = require('path');
const history = require('connect-history-api-fallback');

module.exports = defineConfig({
  transpileDependencies: true,
  devServer: {
    historyApiFallback: true,
    port: 8081,
    proxy: {
      '/api': {
        target: process.env.VUE_APP_API_URL || 'http://localhost:15555',
        changeOrigin: true,
        secure: false,
      },
      '/actuator': {
        target: process.env.VUE_APP_API_URL || 'http://localhost:15555',
        changeOrigin: true,
        secure: false,
      },
      '/stylesheets': {
        target: process.env.VUE_APP_API_URL || 'http://localhost:15555',
        changeOrigin: true,
        secure: false,
      },
      '/javascripts': {
        target: process.env.VUE_APP_API_URL || 'http://localhost:15555',
        changeOrigin: true,
        secure: false,
      },
      '/images': {
        target: process.env.VUE_APP_API_URL || 'http://localhost:15555',
        changeOrigin: true,
        secure: false,
      },
    },
    setupMiddlewares: (middlewares, devServer) => {
      middlewares.unshift(history());
      return middlewares;
    },
  },
  outputDir: path.resolve(__dirname, 'dist'),
  assetsDir: 'static',
  publicPath: process.env.NODE_ENV === 'production' ? '/subfolder/' : '/'
});
