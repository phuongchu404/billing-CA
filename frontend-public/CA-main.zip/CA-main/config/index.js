var path = require('path')

module.exports = {
    build: {
        env: require('./prod.env'),
        index: path.resolve(__dirname, '../../ca_mk/src/main/resources/static/index.html'),
        assetsRoot: path.resolve(__dirname, '../../ca_mk/src/main/resources/static'),
        assetsSubDirectory: 'static',
        assetsPublicPath: '/',
        productionSourceMap: false,
        productionGzip: false,
        productionGzipExtensions: ['js', 'css'],
        bundleAnalyzerReport: process.env.npm_config_report
    },
    dev: {
        env: require('./dev.env'),
        port: 19000,
        autoOpenBrowser: false,
        assetsSubDirectory: 'static',
        assetsPublicPath: '/',
        proxyTable: {
            '/api': {
                target: 'http://127.0.0.1:15555',
                secure: false
            },
            '/stylesheets': {
                target: 'http://127.0.0.1:15555',
                secure: false
            },
            '/javascripts': {
                target: 'http://127.0.0.1:15555',
                secure: false
            },
            '/images': {
                target: 'http://127.0.0.1:15555',
                secure: false
            }

        },
        cssSourceMap: false
    }
}
